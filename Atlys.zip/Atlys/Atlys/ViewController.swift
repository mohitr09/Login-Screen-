//
//  ViewController.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .orange
        // Do any additional setup after loading the view.
    }


}


//
//  LoginViewController.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

class LoginViewController: UIViewController {
    
    //    MARK: Variables
    private lazy var logoImage: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: Constants.appImages.logo)
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    private lazy var craouselVIew: CarouselView = {
        let view = CarouselView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.white
        view.delegate = self
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl(frame: .zero)
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        pageControl.pageIndicatorTintColor = UIColor.lightGray
        pageControl.currentPageIndicatorTintColor = UIColor.darkGray
        pageControl.isUserInteractionEnabled = false
        pageControl.numberOfPages = 3
        pageControl.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        return pageControl
    }()
    
    private lazy var userInputView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var blurView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .orange
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var visaLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.textColor = UIColor.black
        label.font = UIFont.boldSystemFont(ofSize: 34.0)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .center
        label.text = Constants.UIStrings.visaOnTime
        return label
    }()
    
    
    private lazy var phoneNumberField: UITextField = {
        let textField = UITextField(frame: .zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        
        textField.addDoneButtonOnKeyboard()
        textField.placeholder = Constants.UIStrings.enterNumber
        textField.layer.cornerRadius = 10
        textField.keyboardType = .numberPad
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.gray.withAlphaComponent(0.4).cgColor
        let leftContainerView = UIView(frame: CGRect(x: 0, y: 0, width: 68, height: 24))
        
        let leftImageView = UIImageView(image: UIImage(named: Constants.appImages.flag))
        leftImageView.contentMode = .scaleAspectFit
        leftImageView.frame = CGRect(x: 6, y: 0, width: 24, height: 24)
        
        let countryCodeLabel = UILabel(frame: CGRect(x: 34, y: 0, width: 30, height: 24))
        countryCodeLabel.text = Constants.UIStrings.defaultCountryCode
        countryCodeLabel.textColor = .black
        countryCodeLabel.font = UIFont.systemFont(ofSize: 16)
        
        leftContainerView.addSubview(leftImageView)
        leftContainerView.addSubview(countryCodeLabel)
        
        textField.leftView = leftContainerView
        textField.leftViewMode = .always
        textField.delegate = self
        
        return textField
    }()
    
    private lazy var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.contentMode = .scaleAspectFit
        button.layer.cornerRadius = 10
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 155/255, green: 153/255, blue: 239/255, alpha: 1.0)
        button.layer.masksToBounds = true
        button.setTitle(Constants.UIStrings.continueTitle, for: .normal)
        button.addTarget(self, action: #selector(continueBtnTapped), for: .touchUpInside)
        return button
    }()
    
    private lazy var bottomSocialView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .clear
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var leftSepratorView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.lightGray.withAlphaComponent(0.4)
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var orLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.textColor = UIColor.black
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .center
        label.text = Constants.UIStrings.orText
        return label
    }()
    
    private lazy var rightSepratorView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.lightGray.withAlphaComponent(0.4)
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var buttonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .equalSpacing
        stackView.spacing = 34.0
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        let googleBtn = UIButton(type: .custom)
        googleBtn.backgroundColor = .white
        googleBtn.setImage(UIImage(named: Constants.appImages.googleLogin), for: .normal)
        googleBtn.widthAnchor.constraint(equalToConstant: 40).isActive = true
        googleBtn.heightAnchor.constraint(equalToConstant: 40).isActive = true
        googleBtn.layer.cornerRadius = 10.0
        googleBtn.layer.shadowColor = UIColor.black.cgColor
        googleBtn.layer.shadowOpacity = 0.5
        googleBtn.layer.shadowOffset = CGSize(width: 0, height: 2)
        
        
        let appleBtn = UIButton(type: .custom)
        appleBtn.backgroundColor = .white
        appleBtn.setImage(UIImage(named: Constants.appImages.appleLogin), for: .normal)
        appleBtn.widthAnchor.constraint(equalToConstant: 40).isActive = true
        appleBtn.heightAnchor.constraint(equalToConstant: 40).isActive = true
        appleBtn.layer.cornerRadius = 10.0
        appleBtn.layer.shadowColor = UIColor.black.cgColor
        appleBtn.layer.shadowOpacity = 0.5
        appleBtn.layer.shadowOffset = CGSize(width: 0, height: 2)
        
        
        let mailBtn = UIButton(type: .custom)
        mailBtn.backgroundColor = .white
        mailBtn.setImage(UIImage(named: Constants.appImages.mailLogin), for: .normal)
        mailBtn.widthAnchor.constraint(equalToConstant: 40).isActive = true
        mailBtn.heightAnchor.constraint(equalToConstant: 40).isActive = true
        mailBtn.layer.cornerRadius = 10.0
        mailBtn.layer.shadowColor = UIColor.black.cgColor
        mailBtn.layer.shadowOpacity = 0.5
        mailBtn.layer.shadowOffset = CGSize(width: 0, height: 2)
        
        stackView.addArrangedSubview(googleBtn)
        stackView.addArrangedSubview(appleBtn)
        stackView.addArrangedSubview(mailBtn)
        
        return stackView
    }()
    
    
    private lazy var hyperLinkLabel: UILabel = {
        let label = UILabel()
        label.isUserInteractionEnabled = true
        label.translatesAutoresizingMaskIntoConstraints = false
        
        let fullString = NSMutableAttributedString(string: Constants.UIStrings.byContinuing)
        let termsString = NSMutableAttributedString(string: Constants.UIStrings.termsText, attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        let andString = NSMutableAttributedString(string: " &")
        let privacyString = NSMutableAttributedString(string: " \(Constants.UIStrings.privacyText) ", attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        let policyString = NSMutableAttributedString(string: " \(Constants.UIStrings.policyText) ")
        
        fullString.append(termsString)
        fullString.append(andString)
        fullString.append(privacyString)
        fullString.append(policyString)
        
        label.attributedText = fullString
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 12.0)
        label.textColor = .black
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        label.addGestureRecognizer(tapGesture)
        
        return label
    }()
    
    
    // Constraint for craousel height (to be adjusted dynamically)
    private var scrollViewHeightConstraint: NSLayoutConstraint!
    private var userInputViewBottomConstraint: NSLayoutConstraint!
    let bottomSocialViewHeight = 140.0
    let userInputViewHeight = 240.0
    
    lazy var viewModel = AtlysLoginVM()
    
    
    //    MARK: View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.setupDetails()
        self.setupUI()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.scrollToCenterIndex()
    }
    
    
    //    MARK: Deinitializer
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    //    MARK: Add view constraints
    private func setupUI() {
        self.view.backgroundColor = .white
        
        self.view.addSubview(self.logoImage)
        self.logoImage.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 48).isActive = true
        self.logoImage.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        self.logoImage.heightAnchor.constraint(equalToConstant: 60).isActive = true
        self.view.layoutIfNeeded()
        
        let screenHeight = UIScreen.main.bounds.height
        let craouselHeight = screenHeight - bottomSocialViewHeight - userInputViewHeight - 160
        
        self.view.addSubview(craouselVIew)
        self.craouselVIew.topAnchor.constraint(equalTo: self.logoImage.bottomAnchor, constant: 16).isActive = true
        self.craouselVIew.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.craouselVIew.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.scrollViewHeightConstraint = self.craouselVIew.heightAnchor.constraint(equalToConstant: craouselHeight)
        self.scrollViewHeightConstraint.isActive = true
        self.view.layoutIfNeeded()
        
        self.craouselVIew.updateImages(self.viewModel.loginCarouselDetails ?? [])
        
        self.view.addSubview(pageControl)
        self.pageControl.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        self.pageControl.topAnchor.constraint(equalTo: self.craouselVIew.bottomAnchor, constant: 10).isActive = true
        self.view.layoutIfNeeded()
        
        self.view.addSubview(userInputView)
        self.userInputView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.userInputView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.userInputView.heightAnchor.constraint(equalToConstant: userInputViewHeight).isActive = true
        self.userInputViewBottomConstraint = self.userInputView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -bottomSocialViewHeight)
        self.userInputViewBottomConstraint.isActive = true
        self.view.layoutIfNeeded()
        
        self.userInputView.addSubview(blurView)
        self.blurView.topAnchor.constraint(equalTo: self.userInputView.topAnchor).isActive = true
        self.blurView.leadingAnchor.constraint(equalTo: self.userInputView.leadingAnchor).isActive = true
        self.blurView.trailingAnchor.constraint(equalTo: self.userInputView.trailingAnchor).isActive = true
        self.blurView.heightAnchor.constraint(equalToConstant: 18).isActive = true
        self.userInputView.layoutIfNeeded()
        self.blurView.isHidden = true
        
        self.userInputView.addSubview(visaLabel)
        self.visaLabel.topAnchor.constraint(equalTo: self.blurView.topAnchor, constant: 16).isActive = true
        self.visaLabel.leadingAnchor.constraint(equalTo: self.userInputView.leadingAnchor, constant: 16).isActive = true
        self.visaLabel.trailingAnchor.constraint(equalTo: self.userInputView.trailingAnchor, constant: -16).isActive = true
        self.userInputView.layoutIfNeeded()
        
        self.userInputView.addSubview(phoneNumberField)
        self.phoneNumberField.topAnchor.constraint(equalTo: self.visaLabel.bottomAnchor, constant: 12).isActive = true
        self.phoneNumberField.leadingAnchor.constraint(equalTo: self.userInputView.leadingAnchor, constant: 16).isActive = true
        self.phoneNumberField.trailingAnchor.constraint(equalTo: self.userInputView.trailingAnchor, constant: -16).isActive = true
        self.phoneNumberField.heightAnchor.constraint(equalToConstant: 48.0).isActive = true
        self.userInputView.layoutIfNeeded()
        
        self.userInputView.addSubview(continueButton)
        self.continueButton.topAnchor.constraint(equalTo: self.phoneNumberField.bottomAnchor, constant: 10).isActive = true
        self.continueButton.heightAnchor.constraint(equalToConstant: 48).isActive = true
        self.continueButton.leadingAnchor.constraint(equalTo: self.userInputView.leadingAnchor, constant: 16).isActive = true
        self.continueButton.trailingAnchor.constraint(equalTo: self.userInputView.trailingAnchor, constant: -16).isActive = true
        self.userInputView.layoutIfNeeded()
        self.continueButton.isUserInteractionEnabled = false
        
        self.view.addSubview(bottomSocialView)
        self.bottomSocialView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.bottomSocialView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.bottomSocialView.heightAnchor.constraint(equalToConstant: bottomSocialViewHeight).isActive = true
        self.bottomSocialView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        self.view.layoutIfNeeded()
        
        self.bottomSocialView.addSubview(orLabel)
        self.orLabel.topAnchor.constraint(equalTo: self.bottomSocialView.topAnchor, constant: 2).isActive = true
        self.orLabel.centerXAnchor.constraint(equalTo: self.bottomSocialView.centerXAnchor).isActive = true
        self.bottomSocialView.layoutIfNeeded()
        
        self.bottomSocialView.addSubview(leftSepratorView)
        self.leftSepratorView.centerYAnchor.constraint(equalTo: self.orLabel.centerYAnchor).isActive = true
        self.leftSepratorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        self.leftSepratorView.leadingAnchor.constraint(equalTo: self.bottomSocialView.leadingAnchor, constant: 16).isActive = true
        self.leftSepratorView.trailingAnchor.constraint(equalTo: self.orLabel.leadingAnchor, constant: -10).isActive = true
        self.bottomSocialView.layoutIfNeeded()
        
        self.bottomSocialView.addSubview(rightSepratorView)
        self.rightSepratorView.centerYAnchor.constraint(equalTo: self.orLabel.centerYAnchor).isActive = true
        self.rightSepratorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        self.rightSepratorView.trailingAnchor.constraint(equalTo: self.bottomSocialView.trailingAnchor, constant: -16).isActive = true
        self.rightSepratorView.leadingAnchor.constraint(equalTo: self.orLabel.trailingAnchor, constant: 10).isActive = true
        self.bottomSocialView.layoutIfNeeded()
        
        self.bottomSocialView.addSubview(buttonStackView)
        self.buttonStackView.topAnchor.constraint(equalTo: self.orLabel.bottomAnchor, constant: 16).isActive = true
        self.buttonStackView.heightAnchor.constraint(equalToConstant: 44).isActive = true
        self.buttonStackView.centerXAnchor.constraint(equalTo: self.bottomSocialView.centerXAnchor).isActive = true
        self.bottomSocialView.layoutIfNeeded()
        
        self.bottomSocialView.addSubview(hyperLinkLabel)
        self.hyperLinkLabel.topAnchor.constraint(equalTo: self.buttonStackView.bottomAnchor, constant: 10).isActive = true
        self.hyperLinkLabel.trailingAnchor.constraint(equalTo: self.bottomSocialView.trailingAnchor, constant: -16).isActive = true
        self.hyperLinkLabel.leadingAnchor.constraint(equalTo: self.bottomSocialView.leadingAnchor, constant: 16).isActive = true
        self.bottomSocialView.layoutIfNeeded()
    }
    
    
    //    MARK: Inital scroll to center Index
    func scrollToCenterIndex() {
        let centerOffsetX = (self.craouselVIew.scrollView.contentSize.width - self.craouselVIew.scrollView.frame.size.width) / 2
        let centerOffsetY = (self.craouselVIew.scrollView.contentSize.height - self.craouselVIew.scrollView.frame.size.height) / 2
        let centerPoint = CGPoint(x: centerOffsetX, y: centerOffsetY)
        self.craouselVIew.scrollView.setContentOffset(centerPoint, animated: false)
        let initialIndex = ((self.viewModel.loginCarouselDetails?.count ?? 0) / 2)
        self.craouselVIew.centerItemInScrollView(item: self.craouselVIew.carouselContentView[initialIndex], scrollView: self.craouselVIew.scrollView)
        self.pageControl.currentPage = initialIndex
    }
    
    
    //    MARK: Set user input details
    func setUserInputDetails(phoneDetail: String?) {
        if let text = phoneDetail, text.isEmpty == false {
            self.viewModel.userLoginDetails?.phoneNumber = text
            self.continueButton.isUserInteractionEnabled = true
            self.continueButton.backgroundColor = UIColor(red: 84/255, green: 84/255, blue: 248/255, alpha: 1.0)
        }else {
            self.viewModel.userLoginDetails?.phoneNumber = nil
            self.continueButton.isUserInteractionEnabled = false
            self.continueButton.backgroundColor = UIColor(red: 155/255, green: 153/255, blue: 239/255, alpha: 1.0)
        }
    }
    
    
    //    MARK: Check number validation
    private func isPhoneNumberCorrect() -> Bool{
        if let userLoginDetails = viewModel.userLoginDetails, let phoneNo = userLoginDetails.phoneNumber, let _ = userLoginDetails.countryCode {
            if self.isValidPhoneNumber("\(phoneNo)") {
                return true
            }else {
                self.showAlert(title: Constants.UIStrings.invalidNumber, message: Constants.UIStrings.enterNumberAgain)
            }
        }
        return false
    }
    
    
    //      MARK: - Keyboard Notification Handlers
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            let keyboardHeight = keyboardSize.height
            self.blurView.isHidden = false
            self.blurView.applyGradient(colorArray: [UIColor.gray.withAlphaComponent(0.18), UIColor.black.withAlphaComponent(0.0)])
            self.userInputViewBottomConstraint.constant =  -keyboardHeight
            
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        self.userInputViewBottomConstraint.constant = -self.bottomSocialViewHeight
        self.blurView.isHidden = true
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    //    MARK: Actions
    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
        if let url = URL(string: "https://www.google.com") {
            UIApplication.shared.open(url)
        }
    }
    
    @objc func continueBtnTapped() {
        if self.isPhoneNumberCorrect() {
            print("user logged in")
        }
    }
    
}


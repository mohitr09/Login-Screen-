//
//  LoginExtensions.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

// MARK: Login extension
extension LoginViewController: LoginDataProtocol {
    func selectedCarouselIndex(_ value: Int) {
        self.pageControl.currentPage = value
    }
}

// MARK: Login UItextField extension
extension LoginViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.setUserInputDetails(phoneDetail: textField.text)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentText: NSString = (textField.text ?? "") as NSString
        let updatedNumber: NSString =
        currentText.replacingCharacters(in: range, with: string) as NSString
        self.setUserInputDetails(phoneDetail: updatedNumber as String)
        return true
    }
}
extension LoginViewController {
    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneRegex = "^\\+?[0-9]{1,4}?[0-9]{6,14}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: phoneNumber)
    }
}

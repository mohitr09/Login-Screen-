//
//  LoginExtensions.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

extension LoginViewController: LoginDataProtocol {
    func selectedCarouselIndex(_ value: Int) {
        self.pageControl.currentPage = value
    }
}

// MARK: UItextField extension
extension LoginViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.setUserInputDetails(phoneDetail: textField.text)
    }
}

extension LoginViewController {
    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneRegex = "^\\+?[0-9]{1,4}?[0-9]{6,14}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: phoneNumber)
    }
}

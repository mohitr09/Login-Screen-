//
//  CarouselContentView.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

class CarouselContentView: UIView {

    private lazy var backgroundImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "Malasiya")
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    private lazy var verifiedView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 20.0
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        return view
    }()

    private lazy var verifiedIcon: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "verified_icon")
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var countryLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.textColor = UIColor.white
        label.font = .boldSystemFont(ofSize: 24.0)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .left
        label.text = "Malasiya"
        return label
    }()
    
    private lazy var tagView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor(red: 84/255, green: 84/255, blue: 248/255, alpha: 1.0)
        view.roundCorners(corners: [.topRight, .bottomRight], radius: 10.0)
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var tagLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.textColor = UIColor.white
        label.font = .boldSystemFont(ofSize: 14.0)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .left
        label.text = "12K+ Visas on Atlys"
        return label
    }()
    
    var details: AtlysLoginCarouselModel? {
        didSet {
            if let details = self.details {
                self.backgroundImageView.image = UIImage(named: details.countryDetaiil)
                self.countryLabel.text = details.countryDetaiil
                self.tagLabel.text = details.tag
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        self.addSubview(backgroundImageView)
        NSLayoutConstraint.activate([
            self.backgroundImageView.leadingAnchor.constraint(equalTo: leadingAnchor),
            self.backgroundImageView.trailingAnchor.constraint(equalTo: trailingAnchor),
            self.backgroundImageView.topAnchor.constraint(equalTo: topAnchor),
            self.backgroundImageView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        self.backgroundImageView.addSubview(verifiedView)
        NSLayoutConstraint.activate([
            self.verifiedView.trailingAnchor.constraint(equalTo: self.backgroundImageView.trailingAnchor, constant: -10),
            self.verifiedView.topAnchor.constraint(equalTo: self.backgroundImageView.topAnchor, constant: 10),
            self.verifiedView.heightAnchor.constraint(equalToConstant: 40),
            self.verifiedView.widthAnchor.constraint(equalToConstant: 40)
        ])
        
        self.verifiedView.addSubview(verifiedIcon)
        NSLayoutConstraint.activate([
            self.verifiedIcon.leadingAnchor.constraint(equalTo: self.verifiedView.leadingAnchor, constant: 10),
            self.verifiedIcon.trailingAnchor.constraint(equalTo: self.verifiedView.trailingAnchor, constant: -10),
            self.verifiedIcon.topAnchor.constraint(equalTo: self.verifiedView.topAnchor, constant: 10),
            self.verifiedIcon.bottomAnchor.constraint(equalTo: self.verifiedView.bottomAnchor, constant: -10)
        ])
        
        let bottomSpace = (self.frame.height * 0.2)
        self.backgroundImageView.addSubview(tagView)
        NSLayoutConstraint.activate([
            self.tagView.leadingAnchor.constraint(equalTo: self.backgroundImageView.leadingAnchor),
            self.tagView.heightAnchor.constraint(equalToConstant: 34),
            self.tagView.bottomAnchor.constraint(equalTo: self.backgroundImageView.bottomAnchor, constant: -bottomSpace)
        ])
        
        self.tagView.addSubview(tagLabel)
        NSLayoutConstraint.activate([
            self.tagLabel.leadingAnchor.constraint(equalTo: self.tagView.leadingAnchor, constant: 6),
            self.tagLabel.trailingAnchor.constraint(equalTo: self.tagView.trailingAnchor, constant: -6),
            self.tagLabel.bottomAnchor.constraint(equalTo: self.tagView.bottomAnchor, constant: -6),
            self.tagLabel.topAnchor.constraint(equalTo: self.tagView.topAnchor, constant: 6)
        ])

        self.backgroundImageView.addSubview(countryLabel)
        NSLayoutConstraint.activate([
            self.countryLabel.leadingAnchor.constraint(equalTo: self.backgroundImageView.leadingAnchor, constant: 10),
            self.countryLabel.trailingAnchor.constraint(equalTo: self.backgroundImageView.trailingAnchor, constant: -10),
            self.countryLabel.bottomAnchor.constraint(equalTo: self.tagView.topAnchor, constant: -10)
        ])
    }
}

//
//  CarouselView.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

class CarouselView: UIView {
    
    var scrollView: UIScrollView!
     var imageViews: [CarouselContentView] = []
    private var carouselDetails: [AtlysLoginCarouselModel] = []
    private let scaleFactor: CGFloat = 0.8
    weak var delegate: LoginDataProtocol?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupScrollView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupScrollView()
    }
    
    
    private func setupScrollView() {
        scrollView = UIScrollView(frame: self.bounds)
        scrollView.isPagingEnabled = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.delegate = self
        scrollView.decelerationRate = .fast
        self.addSubview(scrollView)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutImages()
    }
    
    private func layoutImages() {
        let imageHeight = self.bounds.height
        
        for imageView in imageViews {
            imageView.removeFromSuperview()
        }
        imageViews.removeAll()
        
        for (index, detail) in carouselDetails.enumerated() {
            let xPosition = CGFloat(index) * imageHeight
            let contentView = CarouselContentView(frame: CGRect(x: xPosition, y: 0, width: imageHeight, height: imageHeight))
            contentView.details = detail
            contentView.tag = index
            contentView.contentMode = .scaleAspectFill
            contentView.layer.cornerRadius = 10.0
            contentView.clipsToBounds = true
            
            scrollView.addSubview(contentView)
            imageViews.append(contentView)
        }
        scrollView.contentSize = CGSize(width: (imageHeight * CGFloat(carouselDetails.count)), height: imageHeight)
    }
    
    func updateImages(_ newImages: [AtlysLoginCarouselModel]) {
        self.carouselDetails = newImages
        self.setupScrollView()
        for imageView in imageViews {
            imageView.removeFromSuperview()
        }
        imageViews.removeAll()
        setNeedsLayout()
    }
    
    func centerItemInScrollView(item: CarouselContentView, scrollView: UIScrollView) {
        let itemCenter = item.center
        let pageIndex = Int(scrollView.contentOffset.x / scrollView.bounds.width)
        for imageView in imageViews {
            let imageViewCenterX = imageView.frame.midX
            let distanceFromCenter = abs(itemCenter.x - imageViewCenterX)
            let maxDistance = scrollView.bounds.width / 2
            
            let scale = max(1 - (distanceFromCenter / maxDistance * scaleFactor), scaleFactor)
            if pageIndex == imageView.tag {
                DispatchQueue.main.async {
                    imageView.transform = CGAffineTransform(scaleX: 1.0, y: scale)
                    imageView.bringSubviewToFront(scrollView)
                }
            }
            else {
                DispatchQueue.main.async {
                    imageView.transform = CGAffineTransform(scaleX: 1.0, y: scale)
                    imageView.sendSubviewToBack(scrollView)
                }
            }
            
        }
       
    }
}

extension CarouselView: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageIndex = Int(round(scrollView.contentOffset.x / self.bounds.height))
        
        for imageView in imageViews {
            if pageIndex == imageView.tag {
                imageView.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                imageView.bringSubviewToFront(scrollView)
                let itemCenter = imageView.center
                let offset = CGPoint(x: itemCenter.x - scrollView.frame.size.width / 2, y: 0)
                scrollView.setContentOffset(offset, animated: false)
            }
            else {
                imageView.transform = CGAffineTransform(scaleX: 1.0, y: 0.9)
                imageView.sendSubviewToBack(scrollView)
            }
            
        }
        self.delegate?.selectedCarouselIndex(pageIndex)
    }
}

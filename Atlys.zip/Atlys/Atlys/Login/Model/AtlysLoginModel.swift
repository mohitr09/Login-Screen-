//
//  AtlysLoginModel.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import Foundation

struct AtlysLoginCarouselModel {
    var countryDetaiil: String
    var tag: String
    var isVerified: Bool
}

struct UserLoginDetails {
    var countryCode: String? = "+91"
    var phoneNumber: String?
}

//
//  AtlysLoginModel.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import Foundation

struct AtlysLoginCarouselModel {
    var name: String
    var imageName: String
    var tag: String
    var isVerified: Bool
}

struct UserLoginDetails {
    var countryCode: String? = "+91"
    var phoneNumber: String?
}

struct CountryData {
    static let countries: [AtlysLoginCarouselModel] = [
        AtlysLoginCarouselModel(name: "Thailand", imageName: "Thailand", tag: , isVerified: true),
        AtlysLoginCarouselModel(name: "Malasiya", imageName: "Malasiya", tag: "12K+ Visas on Atlys", isVerified: false),
        AtlysLoginCarouselModel(name: "Dubai", imageName: "Dubai", tag: "12K+ Visas on Atlys", isVerified: true)
    ]
}

//
//  LoginDataProtocol.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import Foundation

protocol LoginDataProtocol: AnyObject {
    func selectedCarouselIndex(_ value: Int)
}

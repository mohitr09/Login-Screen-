//
//  AtlysLoginVM.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import Foundation

class AtlysLoginVM: NSObject {
    
    var userLoginDetails: UserLoginDetails? = UserLoginDetails()
    var loginCarouselDetails: [AtlysLoginCarouselModel]? = []
    private let countries: [String] = ["Thailand", "Malasiya", "Dubai"]
    
//    MARK:  custom model data
    func setupDetails() {
        self.loginCarouselDetails?.removeAll()
        self.loginCarouselDetails = CountryData.countries
    }
}

//
//  AtlysLoginVM.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import Foundation

class AtlysLoginVM: NSObject {
    
    var userLoginDetails: UserLoginDetails? = UserLoginDetails()
    var loginCarouselDetails: [AtlysLoginCarouselModel]? = []
    private let images: [String] = ["Thailand", "Malasiya", "Dubai"]
    
    func setupDetails() {
        self.loginCarouselDetails?.removeAll()
        
        for image in images {
            self.loginCarouselDetails?.append(AtlysLoginCarouselModel(countryDetaiil: image, tag: "12K+ Visas on Atlys", isVerified: true))
        }
    }
}

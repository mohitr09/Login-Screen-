//
//  CarouselView.swift
//  Atlys
//
//  Created by Mohit on 21/09/24.
//

import UIKit

class CarouselView: UIView {
    
    var scrollView: UIScrollView!
    var carouselContentView: [CarouselContentView] = []
    private var carouselDetails: [AtlysLoginCarouselModel]? = []
    private let scaleFactor: CGFloat = 0.8
    weak var delegate: LoginDataProtocol?
    
//    MARK: initializer
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupScrollView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupScrollView()
    }
    
    
    private func setupScrollView() {
        scrollView = UIScrollView(frame: self.bounds)
        scrollView.isPagingEnabled = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.delegate = self
        scrollView.decelerationRate = .fast
        self.addSubview(scrollView)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutImages()
    }
    
    private func layoutImages() {
        let imageHeight = self.bounds.height
        
        for view in carouselContentView {
            view.removeFromSuperview()
        }
        carouselContentView.removeAll()
        if let carouselDetails = self.carouselDetails {
            for (index, detail) in carouselDetails.enumerated() {
                let xPosition = CGFloat(index) * imageHeight
                let contentView = CarouselContentView(frame: CGRect(x: xPosition, y: 0, width: imageHeight, height: imageHeight))
                contentView.details = detail
                contentView.tag = index
                contentView.contentMode = .scaleAspectFill
                contentView.layer.cornerRadius = 10.0
                contentView.clipsToBounds = true
                
                scrollView.addSubview(contentView)
                carouselContentView.append(contentView)
            }
            scrollView.contentSize = CGSize(width: (imageHeight * CGFloat(carouselDetails.count)), height: imageHeight)
        }
    }
    
    func updateImages(_ newImages: [AtlysLoginCarouselModel]) {
        self.carouselDetails = newImages
        self.setupScrollView()
        for view in carouselContentView {
            view.removeFromSuperview()
        }
        carouselContentView.removeAll()
        setNeedsLayout()
    }
    
    func centerItemInScrollView(item: CarouselContentView, scrollView: UIScrollView) {
        let itemCenter = item.center
        let pageIndex = Int(scrollView.contentOffset.x / scrollView.bounds.width)
        for imageView in carouselContentView {
            let imageViewCenterX = imageView.frame.midX
            let distanceFromCenter = abs(itemCenter.x - imageViewCenterX)
            let maxDistance = scrollView.bounds.width / 2
            
            let scale = max(1 - (distanceFromCenter / maxDistance * scaleFactor), scaleFactor)
            if pageIndex == imageView.tag {
                DispatchQueue.main.async {
                    imageView.transform = CGAffineTransform(scaleX: 1.0, y: scale)
                    imageView.bringSubviewToFront(scrollView)
                }
            }
            else {
                DispatchQueue.main.async {
                    imageView.transform = CGAffineTransform(scaleX: 1.0, y: scale)
                    imageView.sendSubviewToBack(scrollView)
                }
            }
            
        }
        
    }
}

// MARK: UIScrollview extension
extension CarouselView: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageIndex = Int(round(scrollView.contentOffset.x / self.bounds.height))
        
        for view in carouselContentView {
            if pageIndex == view.tag {
                view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                view.bringSubviewToFront(scrollView)
                let itemCenter = view.center
                let offset = CGPoint(x: itemCenter.x - scrollView.frame.size.width / 2, y: 0)
                scrollView.setContentOffset(offset, animated: false)
            }
            else {
                view.transform = CGAffineTransform(scaleX: 1.0, y: 0.9)
                view.sendSubviewToBack(scrollView)
            }
            
        }
        self.delegate?.selectedCarouselIndex(pageIndex)
    }
}

//
//  Constants.swift
//  Atlys
//
//  Created by Mohit on 23/09/24.
//

import Foundation

struct Constants {
    
    // MARK: User Interface Strings
    struct UIStrings {
        static let enterNumber = "Enter phone number"
        static let visaOnTime = "Get Visas\n On Time"
        static let defaultCountryCode = "+91"
        static let continueTitle = "Continue"
        static let orText = "or"
        static let byContinuing = "By continuing, you agree to our "
        static let termsText = "terms"
        static let privacyText = "privacy"
        static let policyText = "policy"
        static let invalidNumber = "Invalid phone number"
        static let enterNumberAgain = "Please enter your phone number again"
    }
    
    // MARK:  images Strings
    struct appImages {
        static let logo = "logo"
        static let flag = "flag_icon"
        static let googleLogin = "google_login"
        static let appleLogin = "apple_login"
        static let mailLogin = "mail_login"
        static let verified = "verified_icon"
    }
    
}
